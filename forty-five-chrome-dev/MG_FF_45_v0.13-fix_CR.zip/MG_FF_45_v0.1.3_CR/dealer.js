/*******************************************************************************
* 
* 
* 
*******************************************************************************/

// dealer.js - Dealer class
// Used for controlling the game state, players turns, playing selected cards
// and analysing the cards in play for illegal moves, wildcards/trumps and scores.

var dealer, currentDealer, dpointer, playerNames, numPlayers;

function dealer() {
	
	this.dealer 		= dealer;
	this.currentDealer 	= currentDealer;
	this.dpointer		= dpointer;
	this.playerNames	= playerNames;
	this.numPlayers 	= numPlayers;

}

function currentDealer() {

	var d;

}

function dpointer() {

	var d1, d2, d3, d4;

	var counter = 0;

	
}